

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";



CREATE TABLE `admin` (`Username` varchar(150) CHARACTER SET utf8 NOT NULL,
  `Password` varchar(20) CHARACTER SET utf8 NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=latin1;




INSERT INTO `admin` (`Username`,  `Password`) VALUES
('hanson', 'kibet');



CREATE TABLE `booking_details` (
  `No` int(11) NOT NULL,
  `source` varchar(150) CHARACTER SET utf8 NOT NULL,
  `destination` varchar(20) CHARACTER SET utf8 NOT NULL,
  `Travelling_Date` varchar(20) CHARACTER SET utf8 NOT NULL,
  `booking_user` varchar(40) CHARACTER SET utf8 NOT NULL,
  `Bus_no` varchar(40) CHARACTER SET utf8 NOT NULL,
  `Seat_no` int(3) DEFAULT NULL,
  `Paid` int(10) DEFAULT NULL,
  `Id` int(10) DEFAULT NULL,
  `First_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `reporting_time` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




CREATE TABLE `busdetails` (
  `Id` int(11) NOT NULL,
  `Bus_No` varchar(150) CHARACTER SET utf8 NOT NULL,
  `source` varchar(20) CHARACTER SET utf8 NOT NULL,
  `destination` varchar(20) CHARACTER SET utf8 NOT NULL,
  `DepartDate` varchar(40) CHARACTER SET utf8 NOT NULL,
  `depart_time` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Price` int(7) DEFAULT NULL,
  `Remaining_seats` int(3) DEFAULT NULL,
  `Bus_type` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




CREATE TABLE `employee` (
 
 `Id` int(11) NOT NULL,
  `Name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `phone` int(12) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




CREATE TABLE `user` (
  `FirstName` varchar(150) CHARACTER SET utf8 NOT NULL,
  `Username` varchar(20) CHARACTER SET utf8 NOT NULL,
  `Phone` int(12) DEFAULT NULL,
  `Email` varchar(40) CHARACTER SET utf8 NOT NULL,
  `Id` int(10) DEFAULT NULL,
  `password` varchar(40) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



ALTER TABLE `booking_details`
  ADD PRIMARY KEY (`No`);

  ALTER TABLE `busdetails`
  ADD PRIMARY KEY (`Id`);
  
  ALTER TABLE `booking_details`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=255;

 
 ALTER TABLE `busdetails`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=255;



